<?php
namespace app\Simple\Model;
use think\Model;

class Opend extends Model{
	
}
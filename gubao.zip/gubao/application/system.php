<?php 
 return array( 
'web_name' => 'Cash Pay',
'web_url' => 'http://s.368ys.cn/',
'web_down' => '',
'web_key' => '',
'fx1' => '0.3',
'fx2' => '0.1',
'logo_url' => '20180526\\c7f0be0b0c97bc841034269f50c9a6bd.jpg',
'QQ' => '123456',
'dx' => '10',
'clo' => 'on',
'txt' => '本次维护网站佣金系统',
'typay' => 'off',
'sxf'=>0.2,
'wid'=>1261,
'wkey'=>121311
); 
 ?>
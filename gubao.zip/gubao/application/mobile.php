<?php 
 return array( 
'dx1_pid' => 'a18236275',
'dx1_pass' => '6730490399',
'dx2_pid' => 'LTAIztBAcxiaLSA',
'dx2_key' => 'LAVn3SFyFqz96YJurD7MzkeM6BVXUQ',
); 
 ?>
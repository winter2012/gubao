<?php
return [
   'template'               => [
        // 模板路径
        'view_path'    => 'public/Home/',
    ],
	//分页配置
    'paginate'               => [
        'type'      => 'bootstrap',
        'var_page'  => 'page',
        'list_rows' => 15,
    ],
];
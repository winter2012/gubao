<?php
namespace app\Home\Model;
use think\Model;
use think\Request;

class Config extends Model{
	
}